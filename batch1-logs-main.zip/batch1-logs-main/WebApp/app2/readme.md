This is a Covid-19 Statistics Viewer for all Countries<br>
For input:<br>
    - Type Country Name <br>
    - Then wait for the results <br>
Api url = https://covid-193.p.rapidapi.com/statistics?country=country? <br>
    - "country?" is the inputted country name after submit
