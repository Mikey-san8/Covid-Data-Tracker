# batch1-logs
This is a simple statistics viewer specified location only in the Philippines with overview of the subject, symptoms, and one of the methods on how to prevent it.<br>
Section 1 <br>
    - The home page and home title<br>
Section 2<br>
    - A tab for:<br>
        1. Overview<br>
        2. Symptoms<br>
        3. Prevention<br>
Section 3<br>
    - Updated Data on Covid-19 in the Philippines<br>
    - Api url (https://covid-193.p.rapidapi.com/statistics?country=Philippines)<br>
Section 4<br>
    - About the subject<br>
    - Directories and suggested websites
